export interface Config
{
    working_dir : string;
    subscription_channel : string;
    express_port : number;
    mqtt_broker_address: string;
    mqtt_client_id : string;

}